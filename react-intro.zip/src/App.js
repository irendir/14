import './App.css';
import Button from "./components/Button";
import Todo from "./components/Todo";
import {useEffect, useState} from "react";
import axios from 'axios';

function App() {
    let list = [{id: 5, name: 'Dima', mark: 3.5},
        {id: 6, name: 'Valya', mark: 3.8},
        {id: 8, name: 'Valera', mark: 4.0}];

    let [countries, setCountries] = useState([]);
    const [todoList, setTodoList] = useState([]);
    useEffect(() => {
        axios.get('https://restcountries.com/v2/all').then(res =>  {
            console.log(res.data);
            let mapped = res.data.map(country => ({
                name: country.name,
                capital: country.capital,
                alpha3Code: country.alpha3Code
            }))
            setCountries(mapped);
        })
    }, [])



    const deleteFromList = name => {
        setTodoList(todoList.filter(el => el !== name));
    }

    return (
        <div className="App">
            <header className="App-header">
                <table>
                    <thead>
                        <tr><th>Name</th><th>Capital</th></tr>
                    </thead>
                    <tbody>
                        {countries.map(country => <tr key={country.alpha3Code}>
                            <td>{country.name}</td>
                            <td>{country.capital}</td>
                        </tr>)}
                    </tbody>

                </table>
                <Todo todoList={todoList} setTodoList={setTodoList} deleteFromList={deleteFromList}/>
                <Button content={"Press Me"} initialValue={777}/>
                <ul>
                    {list.map(el => <li key={el.id}>id: {el.id}, name: {el.name} (mark: {el.mark})</li>)}
                </ul>
                <Button content={"Click Me"} initialValue={5}/>
            </header>
        </div>
    );
}

export default App;
