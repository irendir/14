import {useState} from "react";

function Button({content, initialValue}) {
    let [count, setCount] = useState(initialValue);
    let [name, setName] = useState('');

    const setNewName = e => {
        if(e.keyCode === 13) {
            setName(e.target.value);
        }
    }
    return (
        <>
            <button onClick={() => setCount(count + 1)}>{content} (You clicked {count} times)</button>
            <div>
                Current name: {name}<br/>
                <input type={'text'} onKeyUp={setNewName} />
            </div>
        </>
    )
}

export default Button;