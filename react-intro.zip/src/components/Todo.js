function Todo({todoList, setTodoList, deleteFromList}) {

    const addTodo = e => {
        if(e.keyCode === 13) {
            /*let trash = [];
            for(let item of todoList) {
                trash.push(item);
            }
            trash.push(e.currentTarget.value);*/
            setTodoList([...todoList, e.currentTarget.value]) //the same;

            console.log(todoList);
            e.currentTarget.value = '';
        }
    }

    return (
        <>
            <ul>{todoList.map(todoItem => <li key={todoItem}>{todoItem}
                <button onClick={() => deleteFromList(todoItem)}>Delete</button></li>)}</ul>
            <input type={"text"} onKeyUp={addTodo}/>
        </>
    )
}

export default Todo;